
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "[10,0][10,0][4,1][4,1][1,4][10,0][10,0][4,1][4,0][6,2][5,6]";
		System.out.println(s.length());
		
	}

}
