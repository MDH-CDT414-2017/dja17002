
public class Main {

	public static void main(String[] args) {
		
		BowlingGame b = new BowlingGame("[2,5][2,7][3,3][2,1][4,5][6,2][7,2][3,4][1,8][1,6]");
		//b.splitOnFrames("[2,5][2,7][3,3][2,1][4,5][6,2][7,2][3,4][1,8][1,6]");

		System.out.println(b.getScore("[2,5][2,7][3,3][2,1][4,5][6,2][7,2][3,4][1,8][1,6]"));
	}

}
