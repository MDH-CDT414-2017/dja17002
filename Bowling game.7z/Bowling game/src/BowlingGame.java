import java.util.Arrays;

public class BowlingGame {

	BowlingGame(String wholegame) {
		
	}
	
	public int getScore (String s) {
		int score = 0;
		int [] niz = splitOnFrames(s);
		for (int i = 0; i < splitOnFrames(s).length; i++) {
			score += niz[i];
		}
		
		if (score > 300 || score < 0) {
			return -1;
		}
		
		return score;
	}
	
	public int [] splitOnFrames (String s) {
		
		String samoBrojevi = s.replaceAll("\\D+"," ");
		String[] cut = samoBrojevi.split(" ");
		int [] nizBrojeva = new int [20];

		for (int i = 0; i < cut.length-1; i++) {
			nizBrojeva [i] = Integer.parseInt(cut[i+1]);
		}
		return nizBrojeva;
	}
	
	
	
	
}
