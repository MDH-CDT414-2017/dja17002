import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class BowlingGameTest {

	//BowlingGame game = new BowlingGame("4");
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test //Fails because this method return -1 for now.
	public void test1() {
		BowlingGame game = new BowlingGame("[3,4]");
		assertEquals("open", game.oneFrameResult());
	}
	
	@Test //Let's see if it will pass if we give a number as an input? -No, it fails.
	public void test2() {
		BowlingGame game = new BowlingGame("4");
		assertEquals(-1, game.getScore());
	}
	
	@Test // It passes now, because I added regex for checking if the input is correct.
	// Let's try now to check the spare case. - It fails now...
	public void test3() { 
		BowlingGame game = new BowlingGame("[6,4]");
		assertEquals("spare", game.oneFrameResult());
	}
	
	@Test // Now I will test for a strike case... - It fails.
	public void test4() { 
		BowlingGame game = new BowlingGame("[10,0]");
		assertEquals("strike", game.oneFrameResult());
	}
	
	@Test /* Let's try now to put more than 10 points in one frame... 
	It passes witch is good, because there are only 10 points in one frame. 
    At this point, I covered everything besides calculating the score properly if there are 
	spares or strikes in the game. */
	public void test5() { 
		BowlingGame game = new BowlingGame("[10,6]");
		assertEquals("Wrong input string!", game.oneFrameResult());
	}
	
	@Test // Now I start to test the final score. It calculates the score correctly 
	// if there are no strikes or spares in the game. 
	public void test6() { 
		BowlingGame game = new BowlingGame("[6,1][2,4][6,3][3,4][1,4][5,4][6,1][6,2][1,4][5,4]");
		assertEquals("72", game.getScore()+"");
	}
	
	@Test // Let's try to add strike into the game. - The score is not calculated correctly.
	public void test7() { 
		BowlingGame game = new BowlingGame("[6,1][2,4][10,0][3,4][1,4][5,4][6,1][6,2][1,4][5,4]");
		assertEquals("80", game.getScore()+"");
	}

	@Test // Now I need to test it for two or more strikes in a row. - It fails.
	public void test8() { 
		BowlingGame game = new BowlingGame("[10,0][10,0][4,1][4,1][1,4][1,4][4,1][1,4][1,4][1,4]");
		assertEquals("79", game.getScore()+"");
	}
	
	@Test // Let's test now for the spare. -It fails.
	public void test9() { 
		BowlingGame game = new BowlingGame("[10,0][10,0][4,1][4,1][1,4][1,4][10,0][4,6][10,0][1,4]");
		assertEquals("119", game.getScore()+"");
	}
	
	@Test // Checking if it calculates correctly with a bonus throw in the game. -No, it returns -1 because of the regex.
	public void test10() { 
		BowlingGame game = new BowlingGame("[10,0][10,0][4,1][4,1][1,4][6,4][10,0][4,1][10,0][6,4][5]");
		assertEquals("129", game.getScore()+"");
	}
	
	@Test // Let's test now if there is no spare in the last frame and we put additional throw. 
	// It should return -1. -It fails.
	public void test11() { 
		BowlingGame game = new BowlingGame("[10,0][10,0][4,1][4,1][1,4][6,4][10,0][4,1][10,0][6,2][5]");
		assertEquals("-1", game.getScore()+"");
	}

	@Test // Let's test now for the perfect game (all strikes). -It fails.
	public void test12() { 
		BowlingGame game = new BowlingGame("[10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,10]");
		assertEquals("300", game.getScore()+"");
	}
	
	@Test // Added because of coverage 
	public void test13() { 
		BowlingGame game = new BowlingGame("[10,0][10,0][4,1][4,1][1,4][6,4][10,0][10,0][4,0][6,2][5,6]");
		assertEquals("-1", game.getScore()+"");
	}
	
	@Test // Added because of coverage 
	public void test14() {
		BowlingGame game = new BowlingGame("[0,10]");
		assertEquals("strike", game.oneFrameResult());
	}
	
	@Test // Added because of coverage 
	public void test15() { 
		BowlingGame game = new BowlingGame("[10,0][10,0][4,1][4,1][1,4][6,4][10,0][10,0][4,0][1,2][5,6]");
		assertEquals("-1", game.getScore()+"");
	}
}


















