import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) {
		
		BowlingGame b = new BowlingGame("[2,5][2,7][3,3][2,1][4,5][6,2][7,2][3,4][1,8][1,6]");
		//b.splitOnFrames("[2,5][2,7][3,3][2,1][4,5][6,2][7,2][3,4][1,8][1,6]");

		//System.out.println(b.getScore());
		
		String s = "[10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,10]";
		
		Pattern pattern = Pattern.compile(Pattern.quote(s));
//		System.out.println(s.charAt(52));
		
		/*if (s.length() == 59 && (s.charAt(50)!='1' || s.charAt(51)!='0')) {
			System.out.println("ok");
		}*/
		
		if (s.equals("[10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,10]")) {
			System.out.println("it matches");
		}
		
	}

}
