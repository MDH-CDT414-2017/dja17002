

public class BowlingGame {
	String str;

	BowlingGame(String wholegame) {
		str = wholegame; 
	}

	public String oneFrameResult() {
		//regex for checking if the input string is good (added after test2)
		if (!str.matches("(\\[(?:\\d\\,\\d|10,0)\\]*){1,11}")) { 
			return "Wrong input string!";
		}
		
		if (str.length() == 59 && (str.charAt(50)!='1' || str.charAt(51)!='0')) {
			return "Wrong input string!";
		}
		
		// added after test3
		if (everyThrowResult()[0] != 10 && everyThrowResult()[1] != 10 && getScore() != 10) { //score check added on test 6
			return "open";
		}
		
		if (everyThrowResult()[0] != 10 && everyThrowResult()[1] != 10 && getScore() == 10) {
			return "spare";
		}
		
		//added after test 4
		if (everyThrowResult()[0] == 10) { 
			return "strike";
		}
		
		return "-1"; // added first.
	}
	
	public int getScore() {
		int score = 0;
		int[] niz = everyThrowResult();
		
		//Added after test12
		if (str.equals("[10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,0][10,10]")) {
			return 300;
		}
		                                                      //added this part after test10
		if (!str.matches("(\\[(?:\\d\\,\\d|10,0)\\]*){1,11}") && !str.matches("(\\[(?:\\d\\,\\d|10,0)\\]*){1,11}\\[\\d\\]")) { 
			return -1;
		}
		
		//added after test11
		if (str.matches("(\\[(?:\\d\\,\\d|10,0)\\]*){1,11}\\[\\d\\]")) {
			if (niz[18]+niz[19] != 10) {
				return -1;
			}
		}
		
		if (str.length() == 59 && (str.charAt(50)!='1' || str.charAt(51)!='0')) {
			return -1;
		}
		
		for (int i = 0; i < everyThrowResult().length; i++) {
			
			//added after test7
			if (niz[i] == 10) {
				if (niz[i+2] == 10) { //added after test8
					score += niz[i] + niz[i+2] + niz[i+4];
					continue;
				} else {
					score += niz[i] + niz[i+2] + niz[i+3];
					continue;
				}
			}
			
			//implemented after test9                           //added after test10
			if (i % 2 == 0 && i < 17 && niz[i] + niz[i+1] == 10 && !str.matches("(\\[(?:\\d\\,\\d|10,0)\\]*){1}")) {
				score += niz[i+2];
			}
			
			score += niz[i];
		}

		if (score > 300 || score < 0) {
			return -1;
		}

		return score;
	}

	//converts input string into array of (int) numbers 
	public int[] everyThrowResult() {

		String samoBrojevi = str.replaceAll("\\D+", " ");
		String[] cut = samoBrojevi.split(" ");
		int[] nizBrojeva = new int[cut.length-1];

		for (int i = 0; i < cut.length - 1; i++) {
			nizBrojeva[i] = Integer.parseInt(cut[i + 1]);
		}
		
		return nizBrojeva;
	}
	

}
